clues_mgwcc088_unscrambled = Array.new
instructions = 'Coming soon...'
explanation = '<MA></MA><TEXT>Coming soon...</TEXT>'
Puzzle.create(title: '#88 - ', grid: '', :constructors => Constructor.where(:name => 'Matt Gaffney'), :sources => Source.where(:name => 'Matt Gaffney\'s Weekly Crossword Contest'), publication_date: '2010/2/19', entries: clues_mgwcc088_unscrambled, instructions: instructions, explanation: explanation, puzzle_type: 'meta', puzzle_type: 'meta')